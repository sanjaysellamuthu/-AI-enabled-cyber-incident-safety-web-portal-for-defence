/**
 * content.js
 * Runs in the page context at document_start. Responsibilities:
 *  1. Extract URL features locally (fast, no network round trip needed for this part).
 *  2. Run lightweight DOM/behavior heuristics once the DOM is ready.
 *  3. Send the combined signal to the background service worker, which
 *     orchestrates the full backend scan and owns the risk-report cache.
 */

(function () {
  const currentUrl = window.location.href;

  function collectBehaviorSignals() {
    const forms = Array.from(document.querySelectorAll("form"));
    const passwordFields = document.querySelectorAll('input[type="password"]');
    const iframes = Array.from(document.querySelectorAll("iframe"));

    const hiddenLoginForm = Array.from(passwordFields).some((el) => {
      const style = window.getComputedStyle(el);
      return style.display === "none" || style.visibility === "hidden" || el.offsetParent === null;
    });

    const invisibleIframes = iframes.filter((f) => {
      const style = window.getComputedStyle(f);
      return (parseInt(style.width) <= 1 || parseInt(style.height) <= 1) || style.opacity === "0";
    }).length;

    const externalFormActions = forms.filter((f) => {
      try {
        const actionHost = new URL(f.action, window.location.href).hostname;
        return actionHost && actionHost !== window.location.hostname;
      } catch {
        return false;
      }
    }).length;

    return {
      form_count: forms.length,
      password_field_count: passwordFields.length,
      hidden_login_form: hiddenLoginForm,
      iframe_count: iframes.length,
      invisible_iframe_count: invisibleIframes,
      external_form_action_count: externalFormActions,
      // Deeper checks (clipboard hijack, crypto-mining JS signatures,
      // auto-download triggers) run server-side against the fetched page
      // source in behavior_service.py — the content script only reports
      // what's cheaply observable in the live DOM.
    };
  }

  function sendToBackground() {
    const features = window.ShieldAI?.extractUrlFeatures
      ? window.ShieldAI.extractUrlFeatures(currentUrl)
      : { valid: false };

    const behavior = document.readyState === "loading" ? null : collectBehaviorSignals();

    chrome.runtime.sendMessage({
      type: "PAGE_SIGNALS",
      url: currentUrl,
      urlFeatures: features,
      behavior
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", sendToBackground);
  } else {
    sendToBackground();
  }
})();
