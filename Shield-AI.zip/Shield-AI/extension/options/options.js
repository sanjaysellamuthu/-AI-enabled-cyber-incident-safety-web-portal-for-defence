const SYNC_FIELDS = ["apiBase", "autoScan", "notifyHigh", "voiceAlerts", "darkMode"];
const LOCAL_FIELDS = ["gsbKey", "vtKey"]; // dev-only overrides; production uses backend/.env

async function loadSettings() {
  const sync = await chrome.storage.sync.get(SYNC_FIELDS);
  const local = await chrome.storage.local.get(LOCAL_FIELDS);

  document.getElementById("apiBase").value = sync.apiBase || "http://localhost:8000";
  document.getElementById("autoScan").checked = sync.autoScan !== false;
  document.getElementById("notifyHigh").checked = sync.notifyHigh !== false;
  document.getElementById("voiceAlerts").checked = !!sync.voiceAlerts;
  document.getElementById("darkMode").checked = sync.darkMode !== false;
  document.getElementById("gsbKey").value = local.gsbKey || "";
  document.getElementById("vtKey").value = local.vtKey || "";
}

async function saveSettings() {
  await chrome.storage.sync.set({
    apiBase: document.getElementById("apiBase").value.trim(),
    autoScan: document.getElementById("autoScan").checked,
    notifyHigh: document.getElementById("notifyHigh").checked,
    voiceAlerts: document.getElementById("voiceAlerts").checked,
    darkMode: document.getElementById("darkMode").checked
  });
  await chrome.storage.local.set({
    gsbKey: document.getElementById("gsbKey").value.trim(),
    vtKey: document.getElementById("vtKey").value.trim()
  });
  const status = document.getElementById("saveStatus");
  status.textContent = "Settings saved ✔";
  setTimeout(() => (status.textContent = ""), 2000);
}

async function login() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const apiBase = document.getElementById("apiBase").value.trim() || "http://localhost:8000";
  const statusEl = document.getElementById("loginStatus");

  try {
    const res = await fetch(`${apiBase}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    await chrome.storage.local.set({ authToken: data.access_token });
    statusEl.textContent = "Signed in ✔";
    statusEl.style.color = "var(--emerald)";
  } catch (e) {
    statusEl.textContent = "Sign in failed — check backend URL and credentials.";
    statusEl.style.color = "var(--danger, #ff3b5c)";
  }
}

document.getElementById("saveBtn").addEventListener("click", saveSettings);
document.getElementById("loginBtn").addEventListener("click", login);
loadSettings();
