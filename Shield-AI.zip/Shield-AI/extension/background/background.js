/**
 * background.js — Manifest V3 service worker.
 * Orchestrates: receiving page signals, calling the backend /scan endpoint,
 * caching results per-tab, badge/notification updates, and scan history sync.
 *
 * Note: MV3 service workers are non-persistent, so all state that must
 * survive a worker restart lives in chrome.storage, not module-level vars
 * (a small in-memory cache is used as a fast path and is safe to lose).
 */

importScripts("../utils/api.js");

const scanCache = new Map(); // tabId -> latest scan result (fast-path cache)

async function runScan(url, localSignals) {
  try {
    // In a full deployment this hits POST /scan, which internally fans out
    // to url-analysis, ssl-analysis, domain-analysis, threat-intel and the
    // ML /predict endpoint, returning one combined explainable report.
    const result = await self.ShieldAI.API.scan(url);
    return result;
  } catch (err) {
    console.warn("[Shield AI] backend scan failed, falling back to local heuristic score", err);
    return localFallbackScore(localSignals);
  }
}

/**
 * If the backend is unreachable (offline, self-hosted instance down, etc.)
 * fall back to a coarse local-only score so the popup never shows nothing.
 */
function localFallbackScore(signals) {
  let score = 0;
  const reasons = [];
  const f = signals?.urlFeatures;

  if (f && f.valid) {
    if (!f.is_https) { score += 20; reasons.push("Connection is not using HTTPS"); }
    if (f.is_ip_address) { score += 25; reasons.push("Domain is a raw IP address"); }
    if (f.typosquat_candidate) { score += 30; reasons.push(`URL resembles ${f.typosquat_candidate}.com`); }
    if (f.suspicious_keywords?.length) { score += 10 * f.suspicious_keywords.length; reasons.push("Suspicious keywords in URL"); }
    if (f.homograph_suspected) { score += 25; reasons.push("Non-standard characters detected in domain (possible homograph attack)"); }
    if (f.has_at_symbol) { score += 15; reasons.push("URL contains '@' (common redirection trick)"); }
  }
  if (signals?.behavior?.hidden_login_form) { score += 30; reasons.push("Hidden password field detected"); }
  if (signals?.behavior?.invisible_iframe_count > 0) { score += 15; reasons.push("Invisible iframe(s) detected"); }
  if (signals?.behavior?.external_form_action_count > 0) { score += 15; reasons.push("Form submits data to a third-party domain"); }

  score = Math.min(score, 100);
  return {
    source: "local_fallback",
    risk_score: score,
    threat_level: score >= 70 ? "High" : score >= 40 ? "Medium" : "Low",
    confidence: 0.5, // local heuristic only, not the ML model
    reasons: reasons.length ? reasons : ["No local risk indicators found"],
    recommendation: score >= 70
      ? "Leave this website immediately."
      : score >= 40
        ? "Proceed with caution."
        : "No immediate threats detected."
  };
}

async function updateBadge(tabId, result) {
  const level = result.threat_level || "Unknown";
  const colorMap = { High: "#FF3B5C", Medium: "#FFB020", Low: "#2ECC71", Unknown: "#7A7A7A" };
  await chrome.action.setBadgeBackgroundColor({ tabId, color: colorMap[level] || colorMap.Unknown });
  await chrome.action.setBadgeText({ tabId, text: level === "High" ? "!" : "" });

  if (level === "High") {
    chrome.notifications.create(`shieldai-${tabId}-${Date.now()}`, {
      type: "basic",
      iconUrl: "../icons/icon128.png",
      title: "Shield AI — High Risk Website",
      message: result.reasons?.[0] || "This website was flagged as high risk.",
      priority: 2
    });
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PAGE_SIGNALS") {
    const tabId = sender.tab?.id;
    (async () => {
      const result = await runScan(message.url, message);
      result.scanned_at = new Date().toISOString();
      result.url = message.url;

      if (tabId != null) {
        scanCache.set(tabId, result);
        await updateBadge(tabId, result);
      }

      // Persist a trimmed history locally too (server is source of truth
      // via GET /history once authenticated).
      const { localHistory = [] } = await chrome.storage.local.get("localHistory");
      localHistory.unshift({ url: message.url, risk_score: result.risk_score, threat_level: result.threat_level, scanned_at: result.scanned_at });
      await chrome.storage.local.set({ localHistory: localHistory.slice(0, 200) });
    })();
    return false; // response goes to popup via GET_LATEST_SCAN, not directly here
  }

  if (message.type === "GET_LATEST_SCAN") {
    const tabId = message.tabId;
    sendResponse(scanCache.get(tabId) || null);
    return true;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => scanCache.delete(tabId));
