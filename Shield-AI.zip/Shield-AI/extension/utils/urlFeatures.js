/**
 * urlFeatures.js
 * Lightweight, dependency-free URL/lexical feature extraction that mirrors
 * the server-side feature pipeline (see backend/app/services/url_features.py
 * and ml/features.py) so the extension can do a fast local pre-check before
 * calling the backend, and so both layers stay in sync on feature semantics.
 */

const SUSPICIOUS_KEYWORDS = [
  "login", "verify", "update", "secure", "account", "banking",
  "confirm", "signin", "webscr", "ebayisapi", "paypal", "password",
  "suspended", "unlock", "urgent", "wallet"
];

const KNOWN_BRANDS = [
  "paypal", "google", "microsoft", "apple", "amazon", "netflix",
  "facebook", "instagram", "bankofamerica", "chase", "wellsfargo"
];

function shannonEntropy(str) {
  const freq = {};
  for (const ch of str) freq[ch] = (freq[ch] || 0) + 1;
  const len = str.length;
  return -Object.values(freq).reduce((sum, count) => {
    const p = count / len;
    return sum + p * Math.log2(p);
  }, 0);
}

function isIpAddress(host) {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(host) || /^[0-9a-fA-F:]+$/.test(host) && host.includes(":");
}

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

function detectTyposquatting(domain) {
  const bare = domain.replace(/\.(com|net|org|io|co)$/i, "");
  let closest = null;
  let minDist = Infinity;
  for (const brand of KNOWN_BRANDS) {
    const dist = levenshtein(bare.toLowerCase(), brand);
    if (dist < minDist) {
      minDist = dist;
      closest = brand;
    }
  }
  // Distance 1-2 on a short string = likely typosquat, but exact match is fine.
  return minDist > 0 && minDist <= 2 ? closest : null;
}

function hasHomographChars(str) {
  // Detect mixed-script / non-ASCII characters that could indicate an IDN
  // homograph attack (e.g. Cyrillic 'а' instead of Latin 'a').
  return /[^\x00-\x7F]/.test(str);
}

/**
 * Extract the full feature set for a given URL. Returns a plain object
 * matching the schema expected by POST /url-analysis on the backend.
 */
function extractUrlFeatures(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch (e) {
    return { valid: false, error: "invalid_url" };
  }

  const host = url.hostname;
  const subdomains = host.split(".");
  const suspiciousHits = SUSPICIOUS_KEYWORDS.filter(k =>
    rawUrl.toLowerCase().includes(k)
  );
  const typosquat = detectTyposquatting(host);

  return {
    valid: true,
    url: rawUrl,
    domain: host,
    url_length: rawUrl.length,
    domain_length: host.length,
    num_dots: (host.match(/\./g) || []).length,
    num_hyphens: (host.match(/-/g) || []).length,
    num_digits: (rawUrl.match(/\d/g) || []).length,
    entropy: Number(shannonEntropy(rawUrl).toFixed(3)),
    is_https: url.protocol === "https:",
    is_ip_address: isIpAddress(host),
    subdomain_count: Math.max(subdomains.length - 2, 0),
    suspicious_keywords: suspiciousHits,
    typosquat_candidate: typosquat,
    homograph_suspected: hasHomographChars(host),
    has_at_symbol: rawUrl.includes("@"),
    has_double_slash_redirect: rawUrl.indexOf("//", 8) !== -1
  };
}

// Support both browser (content script) and CommonJS (unit tests) contexts.
if (typeof module !== "undefined" && module.exports) {
  module.exports = { extractUrlFeatures, shannonEntropy, detectTyposquatting };
} else {
  self.ShieldAI = self.ShieldAI || {};
  self.ShieldAI.extractUrlFeatures = extractUrlFeatures;
}
