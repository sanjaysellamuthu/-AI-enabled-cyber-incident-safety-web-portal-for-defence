/**
 * api.js — thin client for the Shield AI backend.
 * Base URL is configurable via chrome.storage (see options page) so users
 * can point the extension at a self-hosted backend instance.
 */

const DEFAULT_API_BASE = "http://localhost:8000";

async function getApiBase() {
  const { apiBase } = await chrome.storage.sync.get("apiBase");
  return apiBase || DEFAULT_API_BASE;
}

async function getAuthToken() {
  const { authToken } = await chrome.storage.local.get("authToken");
  return authToken || null;
}

async function apiRequest(path, { method = "GET", body = null } = {}) {
  const base = await getApiBase();
  const token = await getAuthToken();

  const headers = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${base}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`API ${method} ${path} failed: ${res.status} ${text}`);
  }
  return res.json();
}

const ShieldAPI = {
  scan: (url) => apiRequest("/scan", { method: "POST", body: { url } }),
  urlAnalysis: (url) => apiRequest("/url-analysis", { method: "POST", body: { url } }),
  sslAnalysis: (url) => apiRequest("/ssl-analysis", { method: "POST", body: { url } }),
  domainAnalysis: (url) => apiRequest("/domain-analysis", { method: "POST", body: { url } }),
  behaviorAnalysis: (payload) => apiRequest("/behavior-analysis", { method: "POST", body: payload }),
  predict: (features) => apiRequest("/predict", { method: "POST", body: features }),
  report: (payload) => apiRequest("/report", { method: "POST", body: payload }),
  history: () => apiRequest("/history"),
  dashboard: () => apiRequest("/dashboard"),
  login: (email, password) => apiRequest("/login", { method: "POST", body: { email, password } })
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = { ShieldAPI, apiRequest, getApiBase, getAuthToken };
} else {
  self.ShieldAI = self.ShieldAI || {};
  self.ShieldAI.API = ShieldAPI;
}
