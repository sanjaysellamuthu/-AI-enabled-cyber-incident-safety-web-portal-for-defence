const GAUGE_CIRCUMFERENCE = 440; // 2 * PI * r(70), matches popup.html

function levelClass(level) {
  return (level || "").toLowerCase();
}

function setGauge(score) {
  const arc = document.getElementById("gaugeArc");
  const offset = GAUGE_CIRCUMFERENCE - (GAUGE_CIRCUMFERENCE * Math.min(score, 100)) / 100;
  arc.style.strokeDashoffset = offset;
  arc.style.stroke =
    score >= 70 ? "var(--danger)" : score >= 40 ? "var(--amber)" : "var(--emerald)";
  document.getElementById("gaugeScore").textContent = `${Math.round(score)}`;
}

function renderResult(result, tab) {
  document.getElementById("siteName").textContent = tab?.title || new URL(tab.url).hostname;
  document.getElementById("siteUrl").textContent = tab.url;
  if (tab.favIconUrl) document.getElementById("siteFavicon").src = tab.favIconUrl;

  if (!result) {
    document.getElementById("threatLevel").textContent = "No scan data yet";
    document.getElementById("statusText").textContent = "Waiting for scan…";
    return;
  }

  setGauge(result.risk_score ?? 0);

  const levelEl = document.getElementById("threatLevel");
  levelEl.textContent = `${result.threat_level || "Unknown"} Risk`;
  levelEl.className = `threat-level ${levelClass(result.threat_level)}`;

  document.getElementById("mConfidence").textContent = result.confidence
    ? `${Math.round(result.confidence * 100)}%`
    : "--";
  document.getElementById("mSsl").textContent = result.ssl_status || "--";
  document.getElementById("mDomainAge").textContent = result.domain_age || "--";
  document.getElementById("mThreatIntel").textContent = result.threat_intel_status || "--";

  const list = document.getElementById("reasonsList");
  list.innerHTML = "";
  (result.reasons || []).forEach((r) => {
    const li = document.createElement("li");
    li.textContent = r;
    list.appendChild(li);
  });

  const banner = document.getElementById("recommendationBanner");
  banner.textContent = result.recommendation || "No recommendation available.";
  banner.className =
    "recommendation " +
    (result.threat_level === "High" ? "danger" : result.threat_level === "Medium" ? "warning" : "");

  const statusDot = document.getElementById("statusDot");
  const statusText = document.getElementById("statusText");
  if (result.source === "local_fallback") {
    statusDot.className = "status-dot offline";
    statusText.textContent = "Offline mode — showing local heuristic score only";
  } else {
    statusDot.className = "status-dot online";
    statusText.textContent = `Last scanned ${new Date(result.scanned_at).toLocaleTimeString()}`;
  }
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !/^https?:/.test(tab.url)) {
    document.getElementById("siteName").textContent = "Nothing to scan on this page";
    return;
  }

  chrome.runtime.sendMessage({ type: "GET_LATEST_SCAN", tabId: tab.id }, (result) => {
    renderResult(result, tab);
  });
}

document.getElementById("settingsBtn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});
document.getElementById("dashboardBtn").addEventListener("click", () => {
  chrome.tabs.create({ url: "http://localhost:8000/dashboard" }); // TODO: point at hosted dashboard UI
});
document.getElementById("historyBtn").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, () => {
    // Placeholder: full history view could be a dedicated extension page.
    alert("Full history view: see chrome.storage.local.localHistory, or GET /history once logged in.");
  });
});
document.getElementById("reportBtn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const category = prompt(
    "Report this site as: phishing / scam / malware / fake_shopping / crypto_scam / spam"
  );
  if (!category) return;
  try {
    await self.ShieldAI.API.report({ url: tab.url, category });
    alert("Thanks — report submitted.");
  } catch (e) {
    alert("Could not submit report: backend unreachable.");
  }
});

init();
