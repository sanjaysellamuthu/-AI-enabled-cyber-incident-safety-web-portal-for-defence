# Shield AI — MongoDB Schema

Database: `shield_ai`

## `users`
| Field | Type | Notes |
|---|---|---|
| `_id` | ObjectId | |
| `email` | string | unique index |
| `name` | string | optional |
| `password_hash` | string | bcrypt |
| `is_admin` | bool | default `false` |
| `created_at` | datetime | |

## `scan_history`
| Field | Type | Notes |
|---|---|---|
| `_id` | ObjectId | |
| `user_id` | string \| null | null for anonymous scans |
| `url` | string | |
| `domain` | string | indexed |
| `risk_score` | float | 0–100 |
| `threat_level` | string | `Low` \| `Medium` \| `High` |
| `confidence` | float | 0–1 |
| `ssl_status` | string | |
| `domain_age` | string | |
| `threat_intel_status` | string | |
| `reasons` | string[] | explainable AI output |
| `recommendation` | string | |
| `scanned_at` | datetime | indexed desc, compound with `user_id` |
| `source` | string | e.g. `backend:random_forest`, `local_fallback` |

## `reported_sites`
| Field | Type | Notes |
|---|---|---|
| `_id` | ObjectId | |
| `url` | string | |
| `domain` | string | indexed |
| `category` | string | `phishing` \| `scam` \| `malware` \| `fake_shopping` \| `crypto_scam` \| `spam` |
| `notes` | string \| null | |
| `reported_by` | string | user id or `"anonymous"` |
| `created_at` | datetime | |
| `status` | string | `pending_review` \| `confirmed` \| `dismissed` |

## `safe_sites`
Allow-list. Domains here get a small negative score nudge.
| Field | Type |
|---|---|
| `domain` | string, unique index |
| `added_by` | string |
| `added_at` | datetime |

## `blacklisted_sites`
Deny-list. Instant 100/High result on match.
| Field | Type |
|---|---|
| `domain` | string, unique index |
| `reason` | string |
| `added_by` | string |
| `added_at` | datetime |

## `threat_logs`
Raw log of every threat-intelligence provider call, for audit/debugging and
for the admin panel's "AI Detection Logs" view.
| Field | Type |
|---|---|
| `_id` | ObjectId |
| `url` | string |
| `provider` | string (`google_safe_browsing` \| `virustotal` \| `phishtank` \| `urlscan`) |
| `result` | string |
| `latency_ms` | number |
| `created_at` | datetime |

---

Indexes are created automatically on startup via `app.db.mongo.ensure_indexes()`.
See `database/init_mongo.js` for a manual `mongosh` script that does the same
plus seeds a couple of example blacklist/safe-list entries.
