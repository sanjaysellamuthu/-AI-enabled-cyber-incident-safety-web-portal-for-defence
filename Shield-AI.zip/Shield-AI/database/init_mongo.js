// database/init_mongo.js
// Run with: mongosh shield_ai init_mongo.js
// (The FastAPI app also creates these indexes automatically on startup —
// this script is for manual setup / CI / seeding demo data.)

db = db.getSiblingDB("shield_ai");

db.users.createIndex({ email: 1 }, { unique: true });
db.scan_history.createIndex({ user_id: 1, scanned_at: -1 });
db.scan_history.createIndex({ domain: 1 });
db.blacklisted_sites.createIndex({ domain: 1 }, { unique: true });
db.safe_sites.createIndex({ domain: 1 }, { unique: true });
db.reported_sites.createIndex({ domain: 1, created_at: -1 });

// Seed a couple of example entries for local testing
db.safe_sites.updateOne(
  { domain: "github.com" },
  { $setOnInsert: { domain: "github.com", added_by: "system", added_at: new Date() } },
  { upsert: true }
);

db.blacklisted_sites.updateOne(
  { domain: "example-phishing-test.com" },
  {
    $setOnInsert: {
      domain: "example-phishing-test.com",
      reason: "Seed test entry for blacklist demo",
      added_by: "system",
      added_at: new Date(),
    },
  },
  { upsert: true }
);

print("Shield AI: indexes created and demo data seeded.");
