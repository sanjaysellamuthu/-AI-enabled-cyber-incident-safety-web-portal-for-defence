import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.services.ml_service import predict


def test_predict_returns_expected_shape():
    result = predict({
        "url_length": 30, "domain_length": 15, "num_dots": 1, "num_hyphens": 1,
        "num_digits": 2, "entropy": 4.0, "is_https": True, "is_ip_address": False,
        "subdomain_count": 0, "suspicious_keywords": [], "typosquat_candidate": None,
        "homograph_suspected": False,
    })
    assert "risk_score" in result
    assert "confidence" in result
    assert "model_used" in result
    assert 0 <= result["risk_score"] <= 100
    assert 0 <= result["confidence"] <= 1


def test_predict_flags_suspicious_patterns_higher_than_clean():
    clean = predict({
        "url_length": 20, "domain_length": 10, "num_dots": 1, "num_hyphens": 0,
        "num_digits": 0, "entropy": 3.5, "is_https": True, "is_ip_address": False,
        "subdomain_count": 0, "suspicious_keywords": [], "typosquat_candidate": None,
        "homograph_suspected": False,
    })
    suspicious = predict({
        "url_length": 40, "domain_length": 25, "num_dots": 2, "num_hyphens": 3,
        "num_digits": 5, "entropy": 4.8, "is_https": False, "is_ip_address": True,
        "subdomain_count": 2, "suspicious_keywords": ["login", "verify", "secure"],
        "typosquat_candidate": "paypal", "homograph_suspected": True,
    })
    assert suspicious["risk_score"] > clean["risk_score"]
