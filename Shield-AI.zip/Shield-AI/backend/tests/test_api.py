import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_url_analysis_endpoint():
    r = client.post("/url-analysis", json={"url": "http://paypal-secure-login.com"})
    assert r.status_code == 200
    data = r.json()
    assert data["domain"] == "paypal-secure-login.com"
    assert data["is_https"] is False


def test_predict_endpoint():
    r = client.post("/predict", json={"features": {
        "url_length": 20, "domain_length": 10, "num_dots": 1, "num_hyphens": 0,
        "num_digits": 0, "entropy": 3.5, "is_https": True, "is_ip_address": False,
        "subdomain_count": 0, "suspicious_keywords": [], "typosquat_candidate": None,
        "homograph_suspected": False,
    }})
    assert r.status_code == 200
    data = r.json()
    assert "risk_score" in data


def test_register_and_login_require_valid_payload():
    r = client.post("/login", json={"email": "not-an-email", "password": "x"})
    assert r.status_code == 422  # validation error, not a 500
