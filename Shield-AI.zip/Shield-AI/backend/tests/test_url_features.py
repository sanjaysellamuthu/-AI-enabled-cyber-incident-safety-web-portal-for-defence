import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.services.url_features import extract_features, shannon_entropy, detect_typosquatting


def test_https_detection():
    feats = extract_features("https://example.com")
    assert feats.is_https is True

    feats = extract_features("http://example.com")
    assert feats.is_https is False


def test_ip_address_detection():
    feats = extract_features("http://192.168.1.1/login")
    assert feats.is_ip_address is True

    feats = extract_features("http://example.com")
    assert feats.is_ip_address is False


def test_suspicious_keyword_detection():
    feats = extract_features("http://secure-login-verify.com")
    assert "secure" in feats.suspicious_keywords
    assert "login" in feats.suspicious_keywords
    assert "verify" in feats.suspicious_keywords


def test_typosquat_detection():
    assert detect_typosquatting("paypa1.com") == "paypal"
    assert detect_typosquatting("gooogle.com") == "google"
    assert detect_typosquatting("github.com") is None  # legitimate, not a brand in our list


def test_entropy_is_higher_for_random_strings():
    low_entropy = shannon_entropy("aaaaaaaaaa")
    high_entropy = shannon_entropy("x7Qp9zL2mK")
    assert high_entropy > low_entropy


def test_homograph_detection():
    feats = extract_features("http://xn--pypal-4ve.com")  # punycode-ish, non-ascii won't show here
    # Explicit non-ASCII char case:
    feats2 = extract_features("http://pаypal.com")  # Cyrillic 'а'
    assert feats2.homograph_suspected is True
