"""
POST /scan — the primary orchestration endpoint. Fans out to every analysis
layer in parallel, combines them into a single explainable risk report, and
persists the result to scan_history. This is what the extension calls on
every page load.
"""
import asyncio
from urllib.parse import urlparse

from fastapi import APIRouter, Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.auth.jwt_handler import bearer_scheme
from app.core.security import decode_access_token
from app.db.mongo import blacklisted_sites_collection, safe_sites_collection, scan_history_collection, users_collection
from app.models.schemas import ScanRequest, ScanResult
from app.services import domain_service, ssl_service, threat_intel, url_features
from app.services.ml_service import predict as ml_predict

router = APIRouter(tags=["scan"])


async def _optional_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme)):
    """Scan works anonymously too — but if a valid token is present, results
    get attached to the user's history."""
    if credentials is None:
        return None
    payload = decode_access_token(credentials.credentials)
    if not payload:
        return None
    return await users_collection().find_one({"email": payload["sub"]})


def build_reasons(feats, ssl_result, domain_result, intel, behavior) -> list[str]:
    reasons = []
    if not feats.is_https:
        reasons.append("Connection is not encrypted (no HTTPS)")
    if feats.is_ip_address:
        reasons.append("Website uses a raw IP address instead of a domain name")
    if feats.typosquat_candidate:
        reasons.append(f"URL closely resembles {feats.typosquat_candidate}.com (possible typosquatting)")
    if feats.suspicious_keywords:
        reasons.append(f"Suspicious keywords found in URL: {', '.join(feats.suspicious_keywords[:4])}")
    if feats.homograph_suspected:
        reasons.append("Domain contains non-standard characters (possible homograph attack)")
    if not ssl_result.valid:
        reasons.append("Could not verify a valid SSL certificate")
    elif ssl_result.self_signed:
        reasons.append("Website is using a self-signed SSL certificate")
    if domain_result.domain_age_days is not None and domain_result.domain_age_days < 30:
        reasons.append("Domain was registered very recently (under 30 days ago)")
    if intel.google_safe_browsing == "flagged":
        reasons.append("Flagged by Google Safe Browsing")
    if intel.virustotal == "flagged":
        reasons.append("Flagged as malicious by VirusTotal")
    if intel.phishtank == "flagged":
        reasons.append("Listed in the PhishTank phishing database")
    if behavior.get("crypto_mining_script"):
        reasons.append("Cryptomining script signature detected")
    if behavior.get("clipboard_manipulation"):
        reasons.append("Page attempts to manipulate the clipboard")
    if behavior.get("auto_download_trigger"):
        reasons.append("Page triggers automatic file downloads")
    if behavior.get("redirect_count", 0) >= 3:
        reasons.append(f"Excessive redirects detected ({behavior['redirect_count']})")
    if not reasons:
        reasons.append("No significant risk indicators found")
    return reasons


def recommendation_for(threat_level: str) -> str:
    return {
        "High": "Leave this website immediately.",
        "Medium": "Proceed with caution — verify the site's legitimacy before entering any data.",
        "Low": "No immediate threats detected.",
    }[threat_level]


@router.post("/scan", response_model=ScanResult)
async def scan(payload: ScanRequest, user=Depends(_optional_user)):
    url = payload.url
    domain = urlparse(url if "://" in url else f"http://{url}").hostname or url

    # Fast path: explicit allow/deny lists
    blacklisted = await blacklisted_sites_collection().find_one({"domain": domain})
    if blacklisted:
        result = ScanResult(
            url=url, domain=domain, risk_score=100, threat_level="High", confidence=1.0,
            reasons=["Domain is on the Shield AI blacklist"] + ([blacklisted.get("reason")] if blacklisted.get("reason") else []),
            recommendation=recommendation_for("High"),
        )
        await _persist(result, user)
        return result

    safe = await safe_sites_collection().find_one({"domain": domain})

    feats = url_features.extract_features(url)

    ssl_result, domain_result, intel = await asyncio.gather(
        ssl_service.analyze_ssl(domain),
        domain_service.analyze_domain(domain),
        threat_intel.run_all_checks(url),
    )
    # Behavior analysis is the slowest (full page fetch); run it last / best-effort.
    from app.services.behavior_service import analyze_page_behavior
    behavior = await analyze_page_behavior(url)

    ml_result = ml_predict(feats.model_dump())
    risk_score = ml_result["risk_score"]

    # Nudge score using deterministic signals the ML model may not fully
    # capture yet (blacklist/threat-intel hits are strong evidence).
    if intel.google_safe_browsing == "flagged" or intel.virustotal == "flagged":
        risk_score = max(risk_score, 85)
    if safe and risk_score < 30:
        risk_score = max(risk_score - 10, 0)

    threat_level = "High" if risk_score >= 70 else "Medium" if risk_score >= 40 else "Low"

    result = ScanResult(
        url=url,
        domain=domain,
        risk_score=round(risk_score, 1),
        threat_level=threat_level,
        confidence=ml_result["confidence"],
        ssl_status="Valid" if ssl_result.valid and not ssl_result.self_signed else ("Self-signed" if ssl_result.self_signed else "Invalid/Unavailable"),
        domain_age=f"{domain_result.domain_age_days} days" if domain_result.domain_age_days is not None else "Unknown",
        threat_intel_status="Flagged" if "flagged" in (intel.google_safe_browsing, intel.virustotal, intel.phishtank) else "Clean",
        reasons=build_reasons(feats, ssl_result, domain_result, intel, behavior),
        recommendation=recommendation_for(threat_level),
        source=f"backend:{ml_result['model_used']}",
    )
    await _persist(result, user)
    return result


async def _persist(result: ScanResult, user):
    doc = result.model_dump()
    doc["user_id"] = str(user["_id"]) if user else None
    await scan_history_collection().insert_one(doc)
