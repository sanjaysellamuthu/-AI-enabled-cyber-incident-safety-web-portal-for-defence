from datetime import datetime, timedelta

from fastapi import APIRouter, Depends

from app.auth.jwt_handler import get_current_user
from app.db.mongo import scan_history_collection

router = APIRouter(tags=["dashboard"])


@router.get("/dashboard")
async def get_dashboard(user=Depends(get_current_user)):
    coll = scan_history_collection()
    user_id = str(user["_id"])

    total = await coll.count_documents({"user_id": user_id})
    safe = await coll.count_documents({"user_id": user_id, "threat_level": "Low"})
    dangerous = await coll.count_documents({"user_id": user_id, "threat_level": "High"})

    week_ago = datetime.utcnow() - timedelta(days=7)
    weekly_cursor = coll.find({"user_id": user_id, "scanned_at": {"$gte": week_ago}})
    weekly_items = await weekly_cursor.to_list(length=1000)

    weekly_buckets: dict[str, int] = {}
    for item in weekly_items:
        day = item["scanned_at"].strftime("%Y-%m-%d") if isinstance(item.get("scanned_at"), datetime) else "unknown"
        weekly_buckets[day] = weekly_buckets.get(day, 0) + 1

    recent_cursor = coll.find({"user_id": user_id}).sort("scanned_at", -1).limit(10)
    recent = await recent_cursor.to_list(length=10)
    for item in recent:
        item["_id"] = str(item["_id"])

    # Threat category breakdown pulls from threat_level as a proxy;
    # a richer breakdown (phishing vs malware vs scam) requires tagging
    # scans with a category, which the /report flow already supports for
    # community-reported sites — wire that in for a fuller picture.
    threat_categories = {"phishing": 0, "malware": 0, "scam": 0, "other": dangerous}

    return {
        "total_scanned": total,
        "safe_count": safe,
        "dangerous_count": dangerous,
        "weekly_scans": [{"date": k, "count": v} for k, v in sorted(weekly_buckets.items())],
        "threat_categories": threat_categories,
        "recent_activity": recent,
    }
