from urllib.parse import urlparse

from fastapi import APIRouter

from app.models.schemas import DomainAnalysis, ScanRequest
from app.services.domain_service import analyze_domain

router = APIRouter(tags=["analysis"])


@router.post("/domain-analysis", response_model=DomainAnalysis)
async def domain_analysis(payload: ScanRequest):
    domain = urlparse(payload.url if "://" in payload.url else f"http://{payload.url}").hostname or payload.url
    return await analyze_domain(domain)
