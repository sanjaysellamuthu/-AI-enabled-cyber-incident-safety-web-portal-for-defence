from fastapi import APIRouter

from app.models.schemas import BehaviorAnalysisRequest
from app.services.behavior_service import analyze_page_behavior

router = APIRouter(tags=["analysis"])


@router.post("/behavior-analysis")
async def behavior_analysis(payload: BehaviorAnalysisRequest):
    server_side = await analyze_page_behavior(payload.url)
    return {
        # Client-observed DOM signals (passed through from the extension)
        "client_signals": {
            "form_count": payload.form_count,
            "password_field_count": payload.password_field_count,
            "hidden_login_form": payload.hidden_login_form,
            "iframe_count": payload.iframe_count,
            "invisible_iframe_count": payload.invisible_iframe_count,
            "external_form_action_count": payload.external_form_action_count,
        },
        # Server-fetched page-source signals
        "server_signals": server_side,
    }
