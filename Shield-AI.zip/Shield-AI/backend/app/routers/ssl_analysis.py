from urllib.parse import urlparse

from fastapi import APIRouter

from app.models.schemas import ScanRequest, SslAnalysis
from app.services.ssl_service import analyze_ssl

router = APIRouter(tags=["analysis"])


@router.post("/ssl-analysis", response_model=SslAnalysis)
async def ssl_analysis(payload: ScanRequest):
    domain = urlparse(payload.url if "://" in payload.url else f"http://{payload.url}").hostname or payload.url
    return await analyze_ssl(domain)
