from fastapi import APIRouter

from app.models.schemas import PredictRequest, PredictResponse
from app.services.ml_service import predict as ml_predict

router = APIRouter(tags=["ml"])


@router.post("/predict", response_model=PredictResponse)
async def predict(payload: PredictRequest):
    result = ml_predict(payload.features)
    return PredictResponse(**result)
