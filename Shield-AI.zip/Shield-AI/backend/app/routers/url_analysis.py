from fastapi import APIRouter

from app.models.schemas import ScanRequest, UrlFeatures
from app.services.url_features import extract_features

router = APIRouter(tags=["analysis"])


@router.post("/url-analysis", response_model=UrlFeatures)
async def url_analysis(payload: ScanRequest):
    return extract_features(payload.url)
