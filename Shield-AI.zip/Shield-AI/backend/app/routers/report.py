from datetime import datetime
from urllib.parse import urlparse

from fastapi import APIRouter, Depends

from app.db.mongo import reported_sites_collection
from app.models.schemas import ReportRequest
from app.routers.scan import _optional_user

router = APIRouter(tags=["community"])


@router.post("/report")
async def report_site(payload: ReportRequest, user=Depends(_optional_user)):
    domain = urlparse(payload.url if "://" in payload.url else f"http://{payload.url}").hostname or payload.url
    doc = {
        "url": payload.url,
        "domain": domain,
        "category": payload.category,
        "notes": payload.notes,
        "reported_by": str(user["_id"]) if user else "anonymous",
        "created_at": datetime.utcnow(),
        "status": "pending_review",
    }
    result = await reported_sites_collection().insert_one(doc)
    return {"ok": True, "report_id": str(result.inserted_id)}
