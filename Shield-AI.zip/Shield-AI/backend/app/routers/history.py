from fastapi import APIRouter, Depends, Query

from app.auth.jwt_handler import get_current_user
from app.db.mongo import scan_history_collection

router = APIRouter(tags=["history"])


@router.get("/history")
async def get_history(
    limit: int = Query(50, le=200),
    skip: int = Query(0, ge=0),
    user=Depends(get_current_user),
):
    cursor = (
        scan_history_collection()
        .find({"user_id": str(user["_id"])})
        .sort("scanned_at", -1)
        .skip(skip)
        .limit(limit)
    )
    items = await cursor.to_list(length=limit)
    for item in items:
        item["_id"] = str(item["_id"])
    return {"items": items, "count": len(items)}
