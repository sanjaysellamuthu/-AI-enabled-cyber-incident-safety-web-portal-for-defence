"""
Pydantic schemas shared across routers. Keeping these centralized keeps the
API contract (and therefore the extension <-> backend interface) in one place.
"""
from datetime import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, EmailStr, Field

ThreatLevel = Literal["Low", "Medium", "High"]
ReportCategory = Literal[
    "phishing", "scam", "malware", "fake_shopping", "crypto_scam", "spam"
]


# ---------- Auth ----------
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    name: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- Scan ----------
class ScanRequest(BaseModel):
    url: str


class UrlFeatures(BaseModel):
    url: str
    domain: str
    url_length: int
    domain_length: int
    num_dots: int
    num_hyphens: int
    num_digits: int
    entropy: float
    is_https: bool
    is_ip_address: bool
    subdomain_count: int
    suspicious_keywords: list[str] = []
    typosquat_candidate: Optional[str] = None
    homograph_suspected: bool = False


class SslAnalysis(BaseModel):
    valid: bool
    issuer: Optional[str] = None
    expires_at: Optional[datetime] = None
    self_signed: bool = False
    tls_version: Optional[str] = None
    hsts_enabled: bool = False


class DomainAnalysis(BaseModel):
    domain_age_days: Optional[int] = None
    registrar: Optional[str] = None
    hosting_provider: Optional[str] = None
    country: Optional[str] = None
    asn: Optional[str] = None
    reputation_score: Optional[float] = None


class BehaviorAnalysisRequest(BaseModel):
    url: str
    form_count: int = 0
    password_field_count: int = 0
    hidden_login_form: bool = False
    iframe_count: int = 0
    invisible_iframe_count: int = 0
    external_form_action_count: int = 0


class ThreatIntelResult(BaseModel):
    google_safe_browsing: Optional[str] = None
    virustotal: Optional[str] = None
    phishtank: Optional[str] = None
    urlscan: Optional[str] = None


class PredictRequest(BaseModel):
    features: dict[str, Any]


class PredictResponse(BaseModel):
    risk_score: float
    confidence: float
    model_used: str


class ScanResult(BaseModel):
    url: str
    domain: str
    risk_score: float = Field(ge=0, le=100)
    threat_level: ThreatLevel
    confidence: float
    ssl_status: Optional[str] = None
    domain_age: Optional[str] = None
    threat_intel_status: Optional[str] = None
    reasons: list[str] = []
    recommendation: str
    scanned_at: datetime = Field(default_factory=datetime.utcnow)
    source: str = "backend"


# ---------- Reporting ----------
class ReportRequest(BaseModel):
    url: str
    category: ReportCategory
    notes: Optional[str] = None


# ---------- Dashboard ----------
class DashboardStats(BaseModel):
    total_scanned: int
    safe_count: int
    dangerous_count: int
    weekly_scans: list[dict[str, Any]]
    threat_categories: dict[str, int]
    recent_activity: list[ScanResult]
