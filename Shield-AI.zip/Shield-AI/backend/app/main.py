"""
Shield AI backend entrypoint.
Run locally with: uvicorn app.main:app --reload
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from app.auth.routes import router as auth_router
from app.config import get_settings
from app.db.mongo import ensure_indexes
from app.routers.behavior_analysis import router as behavior_router
from app.routers.dashboard import router as dashboard_router
from app.routers.domain_analysis import router as domain_router
from app.routers.history import router as history_router
from app.routers.predict import router as predict_router
from app.routers.report import router as report_router
from app.routers.scan import router as scan_router
from app.routers.ssl_analysis import router as ssl_router
from app.routers.url_analysis import router as url_router

settings = get_settings()

limiter = Limiter(key_func=get_remote_address, default_limits=[f"{settings.RATE_LIMIT_PER_MINUTE}/minute"])

@asynccontextmanager
async def lifespan(app: FastAPI):
    await ensure_indexes()
    yield


app = FastAPI(
    title="Shield AI API",
    description="AI-powered phishing, scam, and malicious website detection.",
    version="1.0.0",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    # Never leak internals/stack traces to the client.
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.get("/health", tags=["meta"])
async def health():
    return {"status": "ok", "app": settings.APP_NAME, "env": settings.ENV}


app.include_router(auth_router)
app.include_router(scan_router)
app.include_router(url_router)
app.include_router(ssl_router)
app.include_router(domain_router)
app.include_router(behavior_router)
app.include_router(predict_router)
app.include_router(report_router)
app.include_router(history_router)
app.include_router(dashboard_router)
