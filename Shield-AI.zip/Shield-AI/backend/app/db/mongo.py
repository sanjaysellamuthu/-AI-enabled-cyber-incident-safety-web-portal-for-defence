"""
Async MongoDB connection singleton (Motor driver).
Collections: users, scan_history, reported_sites, safe_sites,
blacklisted_sites, threat_logs — see database/schema.md for full schema.
"""
from motor.motor_asyncio import AsyncIOMotorClient
from app.config import get_settings

settings = get_settings()

_client: AsyncIOMotorClient | None = None


def get_client() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(settings.MONGO_URI)
    return _client


def get_db():
    return get_client()[settings.MONGO_DB_NAME]


# Convenience collection accessors
def users_collection():
    return get_db()["users"]


def scan_history_collection():
    return get_db()["scan_history"]


def reported_sites_collection():
    return get_db()["reported_sites"]


def safe_sites_collection():
    return get_db()["safe_sites"]


def blacklisted_sites_collection():
    return get_db()["blacklisted_sites"]


def threat_logs_collection():
    return get_db()["threat_logs"]


async def ensure_indexes():
    """Call once at startup to create indexes required for performance/uniqueness."""
    await users_collection().create_index("email", unique=True)
    await scan_history_collection().create_index([("user_id", 1), ("scanned_at", -1)])
    await scan_history_collection().create_index("domain")
    await blacklisted_sites_collection().create_index("domain", unique=True)
    await safe_sites_collection().create_index("domain", unique=True)
    await reported_sites_collection().create_index([("domain", 1), ("created_at", -1)])
