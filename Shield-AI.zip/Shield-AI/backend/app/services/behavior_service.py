"""
Server-side behavioral analysis. Complements the extension's live-DOM
signals (hidden forms, invisible iframes — already observed client-side)
by fetching the raw page source and scanning for patterns that require
looking at script content rather than the rendered DOM: crypto-mining
scripts, clipboard hijacking, obfuscated redirect chains, password
harvesting via unusual form targets, etc.
"""
import re

import httpx

CRYPTOMINING_SIGNATURES = [
    r"coinhive", r"cryptonight", r"webminer", r"minero\.cc", r"coin-hive",
]
CLIPBOARD_HIJACK_PATTERN = re.compile(r"document\.execCommand\(['\"]copy['\"]\)|navigator\.clipboard\.writeText")
AUTO_DOWNLOAD_PATTERN = re.compile(r"<a[^>]+download[^>]*>|window\.location\s*=\s*['\"][^'\"]+\.(exe|apk|scr|bat)")
POPUP_ABUSE_PATTERN = re.compile(r"window\.open\(.*\)", re.IGNORECASE)


async def analyze_page_behavior(url: str) -> dict:
    findings = {
        "crypto_mining_script": False,
        "clipboard_manipulation": False,
        "auto_download_trigger": False,
        "popup_abuse_score": 0,
        "redirect_count": 0,
        "hsts_enabled": False,
        "fetch_error": None,
    }
    try:
        async with httpx.AsyncClient(timeout=8.0, follow_redirects=True) as client:
            resp = await client.get(url)
            findings["redirect_count"] = len(resp.history)
            findings["hsts_enabled"] = "strict-transport-security" in {
                k.lower() for k in resp.headers.keys()
            }
            body = resp.text.lower()

            findings["crypto_mining_script"] = any(sig in body for sig in CRYPTOMINING_SIGNATURES)
            findings["clipboard_manipulation"] = bool(CLIPBOARD_HIJACK_PATTERN.search(body))
            findings["auto_download_trigger"] = bool(AUTO_DOWNLOAD_PATTERN.search(body))
            findings["popup_abuse_score"] = len(POPUP_ABUSE_PATTERN.findall(body))
    except Exception as e:
        findings["fetch_error"] = str(e)

    return findings
