"""
Loads the trained phishing-detection model (see ml/train.py) and exposes a
predict() function. Falls back to a transparent rule-based scorer if no
trained model artifact is present yet (e.g. fresh clone before running the
ML pipeline), so the API is usable out of the box.
"""
import os
from functools import lru_cache

import joblib
import numpy as np
import pandas as pd

from app.config import get_settings

settings = get_settings()

# Feature order MUST match ml/features.py's FEATURE_COLUMNS exactly.
FEATURE_COLUMNS = [
    "url_length", "domain_length", "num_dots", "num_hyphens", "num_digits",
    "entropy", "is_https", "is_ip_address", "subdomain_count",
    "suspicious_keyword_count", "typosquat_flag", "homograph_flag",
]


@lru_cache
def _load_model():
    path = settings.ML_MODEL_PATH
    if os.path.exists(path):
        bundle = joblib.load(path)
        return bundle["model"], bundle["model_name"]
    return None, None


def _vectorize(features: dict) -> pd.DataFrame:
    row = {
        "url_length": features.get("url_length", 0),
        "domain_length": features.get("domain_length", 0),
        "num_dots": features.get("num_dots", 0),
        "num_hyphens": features.get("num_hyphens", 0),
        "num_digits": features.get("num_digits", 0),
        "entropy": features.get("entropy", 0.0),
        "is_https": int(bool(features.get("is_https"))),
        "is_ip_address": int(bool(features.get("is_ip_address"))),
        "subdomain_count": features.get("subdomain_count", 0),
        "suspicious_keyword_count": len(features.get("suspicious_keywords", []) or []),
        "typosquat_flag": int(bool(features.get("typosquat_candidate"))),
        "homograph_flag": int(bool(features.get("homograph_suspected"))),
    }
    return pd.DataFrame([[row[c] for c in FEATURE_COLUMNS]], columns=FEATURE_COLUMNS)


def _rule_based_fallback(features: dict) -> tuple[float, float]:
    """Transparent rule-based scorer used only when no trained model is
    present. Deliberately conservative and explainable."""
    score = 0.0
    if not features.get("is_https"):
        score += 15
    if features.get("is_ip_address"):
        score += 20
    if features.get("typosquat_candidate"):
        score += 25
    score += min(len(features.get("suspicious_keywords", []) or []) * 8, 24)
    if features.get("homograph_suspected"):
        score += 20
    score += min(features.get("subdomain_count", 0) * 4, 16)
    return min(score, 100.0), 0.55  # low confidence, since it's not the trained model


def predict(features: dict) -> dict:
    model, model_name = _load_model()

    if model is None:
        risk_score, confidence = _rule_based_fallback(features)
        return {"risk_score": risk_score, "confidence": confidence, "model_used": "rule_based_fallback"}

    X = _vectorize(features)
    proba = model.predict_proba(X)[0]
    # Convention: class 1 = phishing/malicious (see ml/train.py label encoding)
    malicious_proba = float(proba[1]) if len(proba) > 1 else float(proba[0])

    return {
        "risk_score": round(malicious_proba * 100, 2),
        "confidence": round(max(proba), 4),
        "model_used": model_name,
    }
