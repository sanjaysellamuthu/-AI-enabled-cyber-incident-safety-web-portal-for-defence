"""
Threat intelligence integrations. Every provider is optional: if its API
key isn't configured, that field is reported as "not_configured" rather
than failing the whole scan — Shield AI degrades gracefully rather than
being all-or-nothing on paid API access.
"""
import httpx

from app.config import get_settings
from app.models.schemas import ThreatIntelResult

settings = get_settings()

GSB_ENDPOINT = "https://safebrowsing.googleapis.com/v4/threatMatches:find"
VT_URL_ENDPOINT = "https://www.virustotal.com/api/v3/urls"
URLSCAN_ENDPOINT = "https://urlscan.io/api/v1/search/"


async def check_google_safe_browsing(url: str) -> str:
    if not settings.GOOGLE_SAFE_BROWSING_API_KEY:
        return "not_configured"
    body = {
        "client": {"clientId": "shield-ai", "clientVersion": "1.0.0"},
        "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": url}],
        },
    }
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                GSB_ENDPOINT, params={"key": settings.GOOGLE_SAFE_BROWSING_API_KEY}, json=body
            )
            data = resp.json()
            return "flagged" if data.get("matches") else "clean"
    except Exception:
        return "error"


async def check_virustotal(url: str) -> str:
    if not settings.VIRUSTOTAL_API_KEY:
        return "not_configured"
    try:
        import base64
        url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
        async with httpx.AsyncClient(timeout=6.0) as client:
            resp = await client.get(
                f"{VT_URL_ENDPOINT}/{url_id}",
                headers={"x-apikey": settings.VIRUSTOTAL_API_KEY},
            )
            if resp.status_code != 200:
                return "unknown"
            stats = resp.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            malicious = stats.get("malicious", 0) + stats.get("suspicious", 0)
            return "flagged" if malicious > 0 else "clean"
    except Exception:
        return "error"


async def check_phishtank(url: str) -> str:
    # PhishTank's public API is IP-rate-limited and keyless for basic checks;
    # an app key increases the quota if provided.
    try:
        async with httpx.AsyncClient(timeout=6.0) as client:
            resp = await client.post(
                "https://checkurl.phishtank.com/checkurl/",
                data={"url": url, "format": "json", "app_key": settings.PHISHTANK_API_KEY or ""},
            )
            if resp.status_code != 200:
                return "unknown"
            data = resp.json()
            in_db = data.get("results", {}).get("in_database")
            if not in_db:
                return "clean"
            return "flagged" if data["results"].get("valid") else "clean"
    except Exception:
        return "error"


async def check_urlscan(url: str) -> str:
    if not settings.URLSCAN_API_KEY:
        return "not_configured"
    try:
        async with httpx.AsyncClient(timeout=6.0) as client:
            resp = await client.get(
                URLSCAN_ENDPOINT,
                params={"q": f"page.url:\"{url}\""},
                headers={"API-Key": settings.URLSCAN_API_KEY},
            )
            if resp.status_code != 200:
                return "unknown"
            results = resp.json().get("results", [])
            flagged = any(r.get("verdicts", {}).get("overall", {}).get("malicious") for r in results)
            return "flagged" if flagged else "clean"
    except Exception:
        return "error"


async def run_all_checks(url: str) -> ThreatIntelResult:
    import asyncio

    gsb, vt, pt, us = await asyncio.gather(
        check_google_safe_browsing(url),
        check_virustotal(url),
        check_phishtank(url),
        check_urlscan(url),
    )
    return ThreatIntelResult(
        google_safe_browsing=gsb, virustotal=vt, phishtank=pt, urlscan=us
    )
