"""
SSL/TLS certificate analysis via a direct socket handshake — no external
API required. Runs in a thread executor since ssl.getpeercert is blocking.
"""
import asyncio
import socket
import ssl
from datetime import datetime

from app.models.schemas import SslAnalysis


def _fetch_cert_sync(hostname: str, port: int = 443, timeout: float = 5.0) -> dict:
    ctx = ssl.create_default_context()
    with socket.create_connection((hostname, port), timeout=timeout) as sock:
        with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            tls_version = ssock.version()
    return {"cert": cert, "tls_version": tls_version}


async def analyze_ssl(hostname: str) -> SslAnalysis:
    try:
        loop = asyncio.get_event_loop()
        data = await loop.run_in_executor(None, _fetch_cert_sync, hostname)
        cert = data["cert"] or {}
        issuer_parts = dict(x[0] for x in cert.get("issuer", []))
        expires_raw = cert.get("notAfter")
        expires_at = (
            datetime.strptime(expires_raw, "%b %d %H:%M:%S %Y %Z") if expires_raw else None
        )
        issuer = issuer_parts.get("organizationName") or issuer_parts.get("commonName")
        subject_parts = dict(x[0] for x in cert.get("subject", []))
        self_signed = issuer_parts.get("commonName") == subject_parts.get("commonName")

        return SslAnalysis(
            valid=True,
            issuer=issuer,
            expires_at=expires_at,
            self_signed=self_signed,
            tls_version=data["tls_version"],
            hsts_enabled=False,  # populated by behavior_service via response headers
        )
    except Exception:
        return SslAnalysis(valid=False, self_signed=False, hsts_enabled=False)
