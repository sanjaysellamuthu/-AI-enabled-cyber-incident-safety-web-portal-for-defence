"""
Domain intelligence via RDAP (modern replacement for raw WHOIS parsing,
no API key required — falls back gracefully if the RDAP bootstrap lookup
or registry doesn't respond).
"""
from datetime import datetime, timezone

import httpx

from app.models.schemas import DomainAnalysis

RDAP_BOOTSTRAP = "https://rdap.org/domain/{domain}"


async def analyze_domain(domain: str) -> DomainAnalysis:
    try:
        async with httpx.AsyncClient(timeout=6.0, follow_redirects=True) as client:
            resp = await client.get(RDAP_BOOTSTRAP.format(domain=domain))
            if resp.status_code != 200:
                return DomainAnalysis()
            data = resp.json()
    except Exception:
        return DomainAnalysis()

    registration_date = None
    for event in data.get("events", []):
        if event.get("eventAction") == "registration":
            registration_date = event.get("eventDate")
            break

    age_days = None
    if registration_date:
        try:
            reg_dt = datetime.fromisoformat(registration_date.replace("Z", "+00:00"))
            age_days = (datetime.now(timezone.utc) - reg_dt).days
        except ValueError:
            pass

    registrar = None
    for entity in data.get("entities", []):
        if "registrar" in entity.get("roles", []):
            vcard = entity.get("vcardArray")
            if vcard and len(vcard) > 1:
                for field in vcard[1]:
                    if field[0] == "fn":
                        registrar = field[3]
            break

    return DomainAnalysis(
        domain_age_days=age_days,
        registrar=registrar,
        hosting_provider=None,  # would require an ASN/IP lookup (e.g. ipinfo.io) — plug in as needed
        country=data.get("country"),
        asn=None,
        reputation_score=None,  # combined downstream from threat_intel + heuristics
    )
