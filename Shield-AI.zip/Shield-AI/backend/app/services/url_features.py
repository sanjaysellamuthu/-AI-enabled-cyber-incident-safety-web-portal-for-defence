"""
Server-side URL feature extraction. This is the canonical implementation used
for ML training/inference (see ml/features.py, which imports the same logic
conceptually) and for the /url-analysis endpoint. Kept dependency-light
(stdlib only) so it can run in constrained environments.
"""
import math
import re
from collections import Counter
from urllib.parse import urlparse

from app.models.schemas import UrlFeatures

SUSPICIOUS_KEYWORDS = [
    "login", "verify", "update", "secure", "account", "banking",
    "confirm", "signin", "webscr", "ebayisapi", "paypal", "password",
    "suspended", "unlock", "urgent", "wallet",
]

KNOWN_BRANDS = [
    "paypal", "google", "microsoft", "apple", "amazon", "netflix",
    "facebook", "instagram", "bankofamerica", "chase", "wellsfargo",
]

IP_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    length = len(s)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    m, n = len(a), len(b)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            dp[i][j] = min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
    return dp[m][n]


def detect_typosquatting(domain: str) -> str | None:
    bare = re.sub(r"\.(com|net|org|io|co)$", "", domain, flags=re.IGNORECASE).lower()
    best_brand, best_dist = None, math.inf
    for brand in KNOWN_BRANDS:
        dist = levenshtein(bare, brand)
        if dist < best_dist:
            best_brand, best_dist = brand, dist
    return best_brand if 0 < best_dist <= 2 else None


def has_homograph_chars(s: str) -> bool:
    return any(ord(ch) > 127 for ch in s)


def extract_features(url: str) -> UrlFeatures:
    parsed = urlparse(url if "://" in url else f"http://{url}")
    domain = parsed.hostname or ""
    subdomain_count = max(domain.count(".") - 1, 0) if domain else 0

    suspicious_hits = [k for k in SUSPICIOUS_KEYWORDS if k in url.lower()]

    return UrlFeatures(
        url=url,
        domain=domain,
        url_length=len(url),
        domain_length=len(domain),
        num_dots=domain.count("."),
        num_hyphens=domain.count("-"),
        num_digits=sum(ch.isdigit() for ch in url),
        entropy=round(shannon_entropy(url), 3),
        is_https=parsed.scheme == "https",
        is_ip_address=bool(IP_RE.match(domain)),
        subdomain_count=subdomain_count,
        suspicious_keywords=suspicious_hits,
        typosquat_candidate=detect_typosquatting(domain) if domain else None,
        homograph_suspected=has_homograph_chars(domain),
    )
