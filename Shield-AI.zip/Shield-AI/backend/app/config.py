"""
Central configuration loaded from environment variables / .env.
Never hardcode secrets — all API keys and credentials come from here.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    APP_NAME: str = "Shield AI"
    ENV: str = "development"
    DEBUG: bool = True

    # Auth
    JWT_SECRET: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24

    # Database
    MONGO_URI: str = "mongodb://localhost:27017"
    MONGO_DB_NAME: str = "shield_ai"

    # Rate limiting
    RATE_LIMIT_PER_MINUTE: int = 60

    # CORS
    CORS_ORIGINS: list[str] = ["chrome-extension://*", "http://localhost:3000"]

    # Threat Intelligence API keys (all optional; each service degrades
    # gracefully to "unavailable" if its key is missing — see threat_intel.py)
    GOOGLE_SAFE_BROWSING_API_KEY: str | None = None
    VIRUSTOTAL_API_KEY: str | None = None
    URLSCAN_API_KEY: str | None = None
    PHISHTANK_API_KEY: str | None = None

    # ML — path is relative to the backend/ working directory (where uvicorn
    # is run from). Override via .env if the model lives elsewhere.
    ML_MODEL_PATH: str = "../ml/models/shield_ai_model.joblib"


@lru_cache
def get_settings() -> Settings:
    return Settings()
