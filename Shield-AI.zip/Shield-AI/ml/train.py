"""
Shield AI model training pipeline.

Usage:
    python ml/train.py --data-path ml/data/sample_dataset.csv --out ml/models/shield_ai_model.joblib

Trains both a Random Forest and an XGBoost classifier on lexical URL
features, evaluates both on a held-out test split, and saves whichever
performs better (by F1 score) along with metadata for reproducibility.
"""
import argparse
import json
import os
from datetime import datetime

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier

from features import FEATURE_COLUMNS, extract_feature_row


def build_feature_dataframe(raw_df: pd.DataFrame) -> pd.DataFrame:
    rows = [extract_feature_row(url) for url in raw_df["url"]]
    feature_df = pd.DataFrame(rows, columns=FEATURE_COLUMNS)
    feature_df["label"] = raw_df["label"].values
    return feature_df


def train(data_path: str, out_path: str, test_size: float = 0.2, random_state: int = 42):
    raw_df = pd.read_csv(data_path)
    if not {"url", "label"}.issubset(raw_df.columns):
        raise ValueError("Dataset must have 'url' and 'label' columns")

    df = build_feature_dataframe(raw_df)
    X = df[FEATURE_COLUMNS]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    candidates = {
        "random_forest": RandomForestClassifier(
            n_estimators=300, max_depth=12, random_state=random_state, class_weight="balanced"
        ),
        "xgboost": XGBClassifier(
            n_estimators=300, max_depth=6, learning_rate=0.08,
            eval_metric="logloss", random_state=random_state,
        ),
    }

    results = {}
    fitted_models = {}
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        proba = model.predict_proba(X_test)[:, 1]
        results[name] = {
            "accuracy": accuracy_score(y_test, preds),
            "f1": f1_score(y_test, preds),
            "roc_auc": roc_auc_score(y_test, proba),
            "report": classification_report(y_test, preds, output_dict=True),
        }
        fitted_models[name] = model
        print(f"\n=== {name} ===")
        print(classification_report(y_test, preds))
        print(f"ROC AUC: {results[name]['roc_auc']:.4f}")

    best_name = max(results, key=lambda n: results[n]["f1"])
    best_model = fitted_models[best_name]
    print(f"\nSelected best model: {best_name} (F1={results[best_name]['f1']:.4f})")

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    joblib.dump(
        {
            "model": best_model,
            "model_name": best_name,
            "feature_columns": FEATURE_COLUMNS,
            "trained_at": datetime.utcnow().isoformat(),
            "metrics": results[best_name],
        },
        out_path,
    )
    print(f"Saved model to {out_path}")

    metrics_path = out_path.replace(".joblib", "_metrics.json")
    with open(metrics_path, "w") as f:
        json.dump({k: {"accuracy": v["accuracy"], "f1": v["f1"], "roc_auc": v["roc_auc"]} for k, v in results.items()}, f, indent=2)
    print(f"Saved comparison metrics to {metrics_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-path", default="ml/data/sample_dataset.csv")
    parser.add_argument("--out", default="ml/models/shield_ai_model.joblib")
    parser.add_argument("--test-size", type=float, default=0.2)
    args = parser.parse_args()

    train(args.data_path, args.out, args.test_size)
