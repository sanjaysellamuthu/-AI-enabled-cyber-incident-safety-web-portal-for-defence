"""
Generates a small SYNTHETIC sample dataset (ml/data/sample_dataset.csv) so
the training pipeline is runnable out of the box for demos/coursework.

This is NOT a real-world threat dataset. For production-quality accuracy,
replace this with an established dataset such as:
  - PhishTank verified phishing feed (https://phishtank.org/developer_info.php)
  - UCI Phishing Websites Dataset
  - Kaggle "Malicious URLs dataset"
Point ml/train.py at the replacement CSV via --data-path.
"""
import csv
import random

random.seed(42)

SAFE_DOMAINS = [
    "github.com", "wikipedia.org", "nytimes.com", "python.org", "stackoverflow.com",
    "amazon.com", "microsoft.com", "apple.com", "spotify.com", "reddit.com",
    "bbc.com", "cloudflare.com", "docs.google.com", "mozilla.org", "npmjs.com",
]
SAFE_PATHS = ["", "/about", "/docs/guide", "/search?q=test", "/products/1234", "/blog/post-1"]

PHISHING_PATTERNS = [
    "paypal-secure-{n}.com/login",
    "verify-account-{n}.net/signin",
    "{n}.192.168.{n}.1/banking",
    "amaz0n-update-{n}.com/confirm",
    "chase-alert-{n}.info/unlock",
    "appleid-verify-{n}.xyz/password",
    "secure-paypa1-{n}.com/webscr",
    "wellsfargo-secure-{n}.top/account",
    "bankofamerica-{n}.support/urgent",
    "netfl1x-billing-{n}.com/update",
]


def make_safe_row():
    domain = random.choice(SAFE_DOMAINS)
    path = random.choice(SAFE_PATHS)
    scheme = "https"
    return f"{scheme}://{domain}{path}", 0


def make_phishing_row():
    pattern = random.choice(PHISHING_PATTERNS)
    n = random.randint(1, 9999)
    scheme = random.choice(["http", "https"])
    return f"{scheme}://{pattern.format(n=n)}", 1


def main(n_per_class=150, out_path="ml/data/sample_dataset.csv"):
    rows = [make_safe_row() for _ in range(n_per_class)] + \
           [make_phishing_row() for _ in range(n_per_class)]
    random.shuffle(rows)

    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["url", "label"])  # label: 0 = safe, 1 = phishing/malicious
        writer.writerows(rows)

    print(f"Wrote {len(rows)} rows to {out_path}")


if __name__ == "__main__":
    main()
