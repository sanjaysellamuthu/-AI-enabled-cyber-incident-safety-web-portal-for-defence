"""
Feature extraction for ML training. This intentionally reuses the exact
same lexical-feature logic as backend/app/services/url_features.py — the
two are kept in sync manually (a shared package would be the next
refactor step) so that vectors produced at inference time match what the
model was trained on.

FEATURE_COLUMNS order is the contract between this file and
backend/app/services/ml_service.py::_vectorize. Do not reorder without
retraining.
"""
import math
import re
from collections import Counter
from urllib.parse import urlparse

FEATURE_COLUMNS = [
    "url_length", "domain_length", "num_dots", "num_hyphens", "num_digits",
    "entropy", "is_https", "is_ip_address", "subdomain_count",
    "suspicious_keyword_count", "typosquat_flag", "homograph_flag",
]

SUSPICIOUS_KEYWORDS = [
    "login", "verify", "update", "secure", "account", "banking",
    "confirm", "signin", "webscr", "ebayisapi", "paypal", "password",
    "suspended", "unlock", "urgent", "wallet",
]
KNOWN_BRANDS = [
    "paypal", "google", "microsoft", "apple", "amazon", "netflix",
    "facebook", "instagram", "bankofamerica", "chase", "wellsfargo",
]
IP_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    length = len(s)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def _levenshtein(a: str, b: str) -> int:
    m, n = len(a), len(b)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            dp[i][j] = min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
    return dp[m][n]


def _is_typosquat(domain: str) -> bool:
    bare = re.sub(r"\.(com|net|org|io|co)$", "", domain, flags=re.IGNORECASE).lower()
    for brand in KNOWN_BRANDS:
        dist = _levenshtein(bare, brand)
        if 0 < dist <= 2:
            return True
    return False


def extract_feature_row(url: str) -> dict:
    parsed = urlparse(url if "://" in url else f"http://{url}")
    domain = parsed.hostname or ""

    return {
        "url_length": len(url),
        "domain_length": len(domain),
        "num_dots": domain.count("."),
        "num_hyphens": domain.count("-"),
        "num_digits": sum(ch.isdigit() for ch in url),
        "entropy": round(_entropy(url), 3),
        "is_https": int(parsed.scheme == "https"),
        "is_ip_address": int(bool(IP_RE.match(domain))),
        "subdomain_count": max(domain.count(".") - 1, 0) if domain else 0,
        "suspicious_keyword_count": sum(1 for k in SUSPICIOUS_KEYWORDS if k in url.lower()),
        "typosquat_flag": int(_is_typosquat(domain)) if domain else 0,
        "homograph_flag": int(any(ord(ch) > 127 for ch in domain)),
    }
