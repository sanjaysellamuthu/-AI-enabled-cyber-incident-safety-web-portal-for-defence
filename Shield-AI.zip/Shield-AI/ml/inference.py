"""
Quick CLI to test the trained model against arbitrary URLs without spinning
up the full backend.

Usage:
    python ml/inference.py "http://paypal-secure-1234.com/login"
"""
import sys

import joblib
import pandas as pd

from features import FEATURE_COLUMNS, extract_feature_row


def load(model_path="ml/models/shield_ai_model.joblib"):
    bundle = joblib.load(model_path)
    return bundle["model"], bundle["model_name"]


def predict_url(url: str, model, model_name: str):
    row = extract_feature_row(url)
    X = pd.DataFrame([[row[c] for c in FEATURE_COLUMNS]], columns=FEATURE_COLUMNS)
    proba = model.predict_proba(X)[0]
    malicious_proba = proba[1] if len(proba) > 1 else proba[0]
    return {
        "url": url,
        "risk_score": round(malicious_proba * 100, 2),
        "model_used": model_name,
        "features": row,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python ml/inference.py <url>")
        sys.exit(1)

    model, name = load()
    result = predict_url(sys.argv[1], model, name)
    print(f"URL: {result['url']}")
    print(f"Model: {result['model_used']}")
    print(f"Risk score: {result['risk_score']}/100")
    print("Features:", result["features"])
