# 🛡️ Shield AI

**AI-Powered Browser Extension for Real-Time Phishing, Scam, and Malicious Website Detection with Explainable Risk Analysis.**

Shield AI scans every webpage before you interact with it and gives you a
transparent risk report — not just "Safe" or "Unsafe" — combining lexical
URL analysis, SSL/TLS checks, domain intelligence, threat-intelligence
feeds, page-behavior scanning, and a trained ML classifier.

## Status

This is a **scaffolded, runnable MVP**, not a finished commercial product.
Core paths (extension → backend → ML model → explainable report) are wired
up and tested end-to-end. Bonus features (admin panel UI, PDF/CSV export,
voice alerts, weekly emails) are stubbed as clear extension points — see
[`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md#future-work--extension-points).

## Project structure

```
Shield-AI/
├── extension/       Chrome Extension (Manifest V3): popup, options, background, content script
├── backend/          FastAPI app: auth, scan orchestration, analysis services, ML inference
├── ml/               Feature extraction, training pipeline, sample dataset, trained model
├── database/         MongoDB schema docs + init script
├── docs/             API reference, installation guide, architecture notes
├── docker/           docker-compose.yml (backend + MongoDB)
├── screenshots/       (add your own screenshots here)
├── requirements.txt
└── README.md
```

## Quick start

```bash
pip install -r requirements.txt
cp backend/.env.example backend/.env        # set JWT_SECRET at minimum
docker run -d -p 27017:27017 mongo:7        # or use docker/docker-compose.yml

python ml/generate_sample_dataset.py
python ml/train.py

cd backend && uvicorn app.main:app --reload
```
Then load `extension/` as an unpacked extension in `chrome://extensions`.

Full walkthrough: [`docs/INSTALLATION.md`](docs/INSTALLATION.md).

## Tech stack

| Layer | Tech |
|---|---|
| Extension | HTML5, CSS3, JS (ES6+), Manifest V3 |
| Backend | Python, FastAPI |
| Database | MongoDB (Motor async driver) |
| ML | scikit-learn (Random Forest), XGBoost, pandas, NumPy |
| Threat intel | Google Safe Browsing, VirusTotal, PhishTank, RDAP/WHOIS |
| Auth | JWT (python-jose) + bcrypt (passlib) |
| Deployment | Docker, Docker Compose |

## What it checks

- **URL features**: length, entropy, IP-address hosts, hyphens/digits,
  suspicious keywords, typosquatting (Levenshtein distance to known
  brands), homograph/Unicode tricks
- **SSL/TLS**: certificate validity, issuer, expiry, self-signed detection,
  TLS version
- **Domain intelligence**: registration age, registrar (via RDAP)
- **Threat intelligence**: Google Safe Browsing, VirusTotal, PhishTank
  (each degrades gracefully to `not_configured` without an API key)
- **Page behavior**: hidden login forms, invisible iframes, cross-domain
  form submission, cryptomining script signatures, clipboard hijacking,
  auto-download triggers, excessive redirects

Every check feeds into a `risk_score` (0–100), a `threat_level`
(Low/Medium/High), and a human-readable `reasons` list — see
[`docs/API.md`](docs/API.md) for the full `/scan` response shape.

## API

Full reference: [`docs/API.md`](docs/API.md). Interactive docs at
`http://localhost:8000/docs` once the backend is running.

## Testing

```bash
cd backend
pytest tests/ -v
```
12 passing tests cover URL feature extraction, ML inference, and core API
endpoints.

## Contributing / extending

This is a solid foundation for a hackathon project, final-year project, or
startup MVP — see [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for design
rationale and the list of extension points (admin panel UI, real dataset,
SHAP-based explainability, bonus features).

## License

Not specified — add a `LICENSE` file appropriate for your intended use
(MIT is a common default for portfolio/hackathon projects).
