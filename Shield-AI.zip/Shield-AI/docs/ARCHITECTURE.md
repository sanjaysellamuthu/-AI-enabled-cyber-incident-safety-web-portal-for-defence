# Architecture

## High-level flow

```
┌─────────────────────┐        ┌──────────────────────────┐
│  Browser Extension   │        │        Backend (FastAPI)  │
│  (Manifest V3)        │        │                            │
│                        │        │  ┌──────────────────────┐ │
│  content.js  ─────────┼───────▶│  │ POST /scan            │ │
│  (URL + DOM signals)   │        │  │  ├─ url_features.py   │ │
│                        │        │  │  ├─ ssl_service.py    │ │
│  background.js         │◀───────┼──┤  ├─ domain_service.py │ │
│  (orchestration,       │  risk  │  │  ├─ threat_intel.py   │ │
│   badge, cache)        │ report │  │  ├─ behavior_service  │ │
│                        │        │  │  └─ ml_service.py ────┼─┼──▶ trained model
│  popup.js (UI)         │        │  └──────────────────────┘ │    (joblib)
└─────────────────────┘        │            │               │
                                 │            ▼               │
                                 │        MongoDB              │
                                 │  users / scan_history /      │
                                 │  reported_sites / ...        │
                                 └──────────────────────────┘
```

## Why this split

**Client-side (extension)**: does cheap, synchronous checks (URL lexical
features, live-DOM heuristics like hidden password fields) so the popup can
show *something* instantly and so the extension still works in a degraded
"local fallback" mode if the backend is unreachable. It never makes the
final trust decision alone.

**Server-side (backend)**: owns everything that needs secrets (threat-intel
API keys), needs to fetch page source itself (avoids relying on a
potentially-compromised page's own JS to self-report), or needs shared state
(blacklist/safe-list, scan history, dashboards). This is also where the
trained ML model lives — extensions can't easily ship or run scikit-learn
models client-side.

## Explainability by design

Every layer (`url_features`, `ssl_service`, `domain_service`,
`threat_intel`, `behavior_service`) returns structured, typed data — never a
single opaque score. `scan.py::build_reasons()` turns those structured
findings into the human-readable "Reasons" list. The ML model contributes
the base `risk_score`, but the *why* is always assembled from named,
inspectable signals, not extracted from the model itself (no SHAP/LIME
layer is wired in yet — see "Future work" below).

## Graceful degradation

- Missing threat-intel API key → that provider reports `not_configured`
  rather than failing the scan.
- Backend unreachable → extension falls back to `background.js::localFallbackScore()`,
  a transparent rule-based heuristic.
- No trained model artifact present → `ml_service.py` falls back to a
  rule-based scorer so `/predict` and `/scan` still work out of the box.

## Data model
See `database/schema.md` for full collection schemas.

## Future work / extension points
- Swap the rule-based "reasons" builder for real SHAP feature attributions
  from the trained model.
- ASN/hosting-provider lookup (currently a stub in `domain_service.py`).
- Admin panel frontend (API surface exists via `/dashboard`, `/history`;
  a dedicated React admin UI is not yet scaffolded).
- Bonus features (PDF export, CSV export, voice alerts, weekly email
  digests) — hooks exist in the options page UI but are not wired to a
  backend job scheduler yet.
