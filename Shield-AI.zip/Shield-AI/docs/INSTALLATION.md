# Installation Guide

## Prerequisites
- Python 3.11+
- Node is **not** required (the extension is vanilla JS)
- MongoDB 6+ (local install, or use the provided Docker Compose)
- Google Chrome or any Chromium-based browser (for the extension)

## 1. Clone & install backend dependencies
```bash
git clone <this-repo>
cd Shield-AI
python3 -m venv .venv
source .venv/bin/activate         # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Configure environment
```bash
cp backend/.env.example backend/.env
# Edit backend/.env — at minimum set JWT_SECRET.
# Threat-intel API keys are optional; leave blank to run without them.
```

## 3. Start MongoDB
Option A — Docker:
```bash
docker run -d -p 27017:27017 --name shield-ai-mongo mongo:7
```
Option B — use the full Docker Compose stack (see step 6).

## 4. Train the ML model
```bash
python ml/generate_sample_dataset.py        # creates ml/data/sample_dataset.csv
python ml/train.py --data-path ml/data/sample_dataset.csv --out ml/models/shield_ai_model.joblib
```
> The bundled sample dataset is synthetic and for demo purposes only.
> Swap in a real dataset (PhishTank feed, UCI Phishing Websites dataset,
> etc.) with the same `url,label` CSV format for production accuracy.

## 5. Run the backend
```bash
cd backend
uvicorn app.main:app --reload
```
Visit `http://localhost:8000/docs` for interactive API docs.

## 6. (Alternative) Run everything with Docker Compose
```bash
cd docker
docker compose up --build
```
This starts MongoDB and the backend together. Train the model first (step 4)
since the compose file mounts `ml/models` read-only into the container.

## 7. Load the browser extension
1. Open Chrome → `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select the `extension/` folder
5. Click the Shield AI icon → gear icon → confirm **API Base URL** is
   `http://localhost:8000` (default)

## 8. Verify
- Visit any website — the extension badge should update within a second or two.
- Click the toolbar icon to see the full risk report.
- `curl http://localhost:8000/health` should return `{"status": "ok", ...}`.

## Running tests
```bash
cd backend
pytest tests/ -v
```
